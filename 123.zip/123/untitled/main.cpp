#include <QApplication>
#include <QTabWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QPalette>
#include <QFont>
#include <QFileDialog>

// 組員1的功能：改變文字顏色
void changeTextColor(QLabel *label) {
    QPalette palette = label->palette();
    palette.setColor(QPalette::WindowText, Qt::red);  // 改變為紅色
    label->setPalette(palette);
}

void addColorButton(QVBoxLayout *layout, QLabel *label) {
    QPushButton *colorButton = new QPushButton("改變文字顏色");
    layout->addWidget(colorButton);

    QObject::connect(colorButton, &QPushButton::clicked, [label]() {
        changeTextColor(label);
    });
}

// 組員2的功能：改變文字樣式
void changeTextStyle(QLabel *label) {
    QFont font = label->font();
    font.setBold(true);  // 文字加粗
    font.setItalic(true);  // 文字斜體
    label->setFont(font);
}

void addStyleButton(QVBoxLayout *layout, QLabel *label) {
    QPushButton *styleButton = new QPushButton("改變文字樣式");
    layout->addWidget(styleButton);

    QObject::connect(styleButton, &QPushButton::clicked, [label]() {
        changeTextStyle(label);
    });
}

// 組員3的功能：選擇檔案並顯示路徑
void chooseFileAndSetPath(QLabel *label) {
    QString filePath = QFileDialog::getOpenFileName(nullptr, "選擇檔案", "", "所有檔案 (*.*)");
    if (!filePath.isEmpty()) {
        label->setText(filePath);
    }
}

void addFileButton(QVBoxLayout *layout, QLabel *label) {
    QPushButton *fileButton = new QPushButton("選擇檔案");
    layout->addWidget(fileButton);

    QObject::connect(fileButton, &QPushButton::clicked, [label]() {
        chooseFileAndSetPath(label);
    });
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // 創建主窗口
    QWidget *window = new QWidget;
    window->setWindowTitle("Widget 協作");

    // 創建Tab Widget
    QTabWidget *tabWidget = new QTabWidget;

    // 創建隊長頁面
    QWidget *leaderPage = new QWidget;
    QVBoxLayout *leaderLayout = new QVBoxLayout;

    QLabel *labelName = new QLabel("隊長: 王小明");
    QLabel *labelID = new QLabel("學號: A12345678");
    QLabel *labelI = new QLabel("組員1: 吳佩儒");
    QLabel *labelI1 = new QLabel("組員2: 彭毓升");
    QLabel *labelI2 = new QLabel("組員3: 吳祥賓");

    // 添加標籤到隊長頁
    leaderLayout->addWidget(labelName);
    leaderLayout->addWidget(labelID);
    leaderLayout->addWidget(labelI);
    leaderLayout->addWidget(labelI1);
    leaderLayout->addWidget(labelI2);

    leaderPage->setLayout(leaderLayout);
    tabWidget->addTab(leaderPage, "隊長頁");

    // 組員1頁面：改變文字顏色
    QWidget *colorPage = new QWidget;
    QVBoxLayout *colorLayout = new QVBoxLayout;
    QLabel *colorLabel = new QLabel("組員1: 吳佩儒");
    colorLayout->addWidget(colorLabel);
    addColorButton(colorLayout, colorLabel);
    colorPage->setLayout(colorLayout);
    tabWidget->addTab(colorPage, "吳佩儒");

    // 組員2頁面：改變文字樣式
    QWidget *stylePage = new QWidget;
    QVBoxLayout *styleLayout = new QVBoxLayout;
    QLabel *styleLabel = new QLabel("組員2: 彭毓升");
    styleLayout->addWidget(styleLabel);
    addStyleButton(styleLayout, styleLabel);
    stylePage->setLayout(styleLayout);
    tabWidget->addTab(stylePage, "彭毓升");

    // 組員3頁面：選擇檔案並顯示路徑
    QWidget *filePage = new QWidget;
    QVBoxLayout *fileLayout = new QVBoxLayout;
    QLabel *fileLabel = new QLabel("組員3: 吳祥賓");
    fileLayout->addWidget(fileLabel);
    addFileButton(fileLayout, fileLabel);
    filePage->setLayout(fileLayout);
    tabWidget->addTab(filePage, "吳祥賓");

    // 設置主布局
    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tabWidget);
    window->setLayout(mainLayout);

    window->resize(400, 300);
    window->show();

    return app.exec();
}
