#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{

    QColor color = QColorDialog::getColor(Qt::white, this, "Choose Text Color");


    if (color.isValid()) {

        QString style = QString("QLabel { color : %1; }").arg(color.name());
        ui->label->setStyleSheet(style);
    }
}

